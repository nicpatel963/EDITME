﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EditMe
{
    public partial class Form1 : Form
    {
        String fname;
        public Form1()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            switch (MessageBox.Show("open new file will erase current data.", "caption", MessageBoxButtons.YesNoCancel))
            {
                case DialogResult.Yes:{
                         SaveFileDialog sfd = new SaveFileDialog();
                         sfd.ShowDialog();
                         fname = sfd.FileName;
                         richTextBox1.SaveFile(fname+".doc",RichTextBoxStreamType.RichText);
                        this.Text = fname+":"+this.Text;
                    } break;
                case DialogResult.No: richTextBox1.Clear(); break;
                case DialogResult.Cancel: break;
               }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter= "All|*.*|Text|*.txt|docs|*.docx*";
            ofd.InitialDirectory = @"D:\";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                fname = ofd.FileName;
                richTextBox1.LoadFile(fname,RichTextBoxStreamType.RichText);
            }
            else
            {
                MessageBox.Show("File not selected");
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectedText = "";
        }

        private void fontToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            richTextBox1.SelectionFont = fd.Font;
        }

        private void styleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void sizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            richTextBox1.SelectionColor = cd.Color;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fname == "")
            {
                SaveFileDialog sfd = new SaveFileDialog();
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    sfd.ShowDialog();
                    fname = sfd.FileName;
                    richTextBox1.SaveFile(fname + ".doc", RichTextBoxStreamType.RichText);
                    this.Text = fname + ":" + this.Text;
                }
            }
            else
            {
                richTextBox1.SaveFile(fname + ".doc", RichTextBoxStreamType.RichText);
                this.Text = fname + ":" + this.Text;
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                sfd.ShowDialog();
                fname = sfd.FileName;
                richTextBox1.SaveFile(fname + ".doc", RichTextBoxStreamType.RichText);
                this.Text = fname + ":" + this.Text;
            }
        }

    }
}
